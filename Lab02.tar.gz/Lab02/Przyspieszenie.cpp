float Przyspieszenie()
{
    return 9.8;
}
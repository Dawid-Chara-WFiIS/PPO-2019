float Czas()
{
    return 1.4;
}
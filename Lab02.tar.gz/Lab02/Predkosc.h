#pragma once
int Predkosc();
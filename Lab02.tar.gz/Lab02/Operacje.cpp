float Iloczyn(float a, float b)
{
    return a*b;
}


float Kwadrat(float arg)
{
    return Iloczyn(arg, arg);
}

float Suma(float a, float b)
{
    return a+b;
}
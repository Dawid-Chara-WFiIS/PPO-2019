#pragma once
float Czas();
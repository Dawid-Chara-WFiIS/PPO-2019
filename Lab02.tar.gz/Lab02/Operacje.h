#pragma once

float Iloczyn(float, float);
float Kwadrat(float);
float Suma(float, float);

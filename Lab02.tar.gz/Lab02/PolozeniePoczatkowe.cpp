int PolozeniePoczatkowe()
{
    return 22;
}
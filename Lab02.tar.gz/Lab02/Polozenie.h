#pragma once
float Polozenie();
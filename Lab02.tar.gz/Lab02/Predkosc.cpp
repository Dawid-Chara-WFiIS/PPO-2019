int Predkosc()
{
    return 333;
}
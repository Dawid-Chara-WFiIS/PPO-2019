#pragma once
#include <iostream>
float Przyspieszenie();
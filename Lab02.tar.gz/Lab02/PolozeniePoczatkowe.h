#pragma once
int PolozeniePoczatkowe();
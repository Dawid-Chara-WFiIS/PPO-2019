#pragma once
#include "SeriesInterface.h"
SeriesPtr InitializeGeometricSeries(Size, SeriesType);



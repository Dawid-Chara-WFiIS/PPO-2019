#pragma once
#include "SeriesInterface.h"
SeriesPtr InitializeHarmonicSeries(Size);



